import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class subString{
    public static void main(String [] args){
        System.out.println("Pos = "+acharSub("hello world","llo wor"));
        System.out.println("Pos = "+acharSub("hello world","llowor"));
        String strTmp = "";

        try {
            File myObj = new File("texto.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
              strTmp = myReader.nextLine();
            }
            myReader.close();
          } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
          }

          System.out.println("Pos = "+acharSub(strTmp,"Agaragan"));
    }

    public static int acharSub(String s1, String s2){
        char char1 [] = new char [s1.length()];
        char char2 [] = new char [s2.length()];
        
        for(int i = 0; i < s1.length(); i++){
            char1[i] = s1.charAt(i);
        }

        for(int i = 0; i < s2.length(); i++){
            char2[i] = s2.charAt(i);
        }

        for(int i = 0; i < char1.length; i++){
            if(char2[0] == char1[i]){
                for(int j = 1; j < char2.length; j++){
                    if(char1[i+j] == char2[j]){
                        if(j == char2.length-1){
                            return i;
                        }
                    }else{
                        break;
                    }
                }
            }
        }

        return -1;
    }
}